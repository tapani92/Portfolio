#include "dllpincodeengine.h"
#include "ui_dllpincodeengine.h"

DLLPinCodeEngine::DLLPinCodeEngine(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DLLPinCodeEngine)
{

}

QString DLLPinCodeEngine::startDLLEngine(short countParameter)
{
    maxCount=countParameter;
    qDebug()<<"Moottoriluokka";
    ui->setupUi(this);
    this->show();
}

DLLPinCodeEngine::~DLLPinCodeEngine()
{
    delete ui;
}

void DLLPinCodeEngine::on_pushButton_1_clicked()
{
    buttonFunction("1");
}

void DLLPinCodeEngine::on_pushButton_2_clicked()
{
    buttonFunction("2");
}

void DLLPinCodeEngine::on_pushButton_3_clicked()
{
    buttonFunction("3");
}

void DLLPinCodeEngine::on_pushButton_4_clicked()
{
    buttonFunction("4");
}

void DLLPinCodeEngine::on_pushButton_5_clicked()
{
   buttonFunction("5");
}

void DLLPinCodeEngine::on_pushButton_6_clicked()
{
    buttonFunction("6");
}

void DLLPinCodeEngine::on_pushButton_7_clicked()
{
    buttonFunction("7");
}

void DLLPinCodeEngine::on_pushButton_8_clicked()
{
   buttonFunction("8");
}

void DLLPinCodeEngine::on_pushButton_9_clicked()
{
    buttonFunction("9");
}

void DLLPinCodeEngine::on_pushButton_0_clicked()
{
   buttonFunction("0");
}

void DLLPinCodeEngine::on_pushButton_OK_clicked()
{
    emit codeString(str);
}

void DLLPinCodeEngine::on_pushButton_Peruuta_clicked()
{
    this->close();
}

void DLLPinCodeEngine::on_pushButton_RESET_clicked()
{
    ui->label->clear();
    ui->label->setText("_____________");
    star.clear();
    pincode.clear();
    pinCount=0;
    str="";
}


void DLLPinCodeEngine::buttonFunction(QString number)
{
    ui->label_3->setText("");
    if(pinCount<maxCount)
    {
        str=str+number;
        pincode.append(number);
        star.append("*");
        ui->label->setText(star);
        qDebug()<<str;
        pinCount++;
    }
    else
    {
        qDebug()<<"Ei ennaa";
    }
}

