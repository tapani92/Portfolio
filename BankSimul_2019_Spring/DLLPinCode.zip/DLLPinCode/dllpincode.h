#ifndef DLLPINCODE_H
#define DLLPINCODE_H
#include<QDebug>
#include "dllpincode_global.h"
#include"dllpincodeengine.h"
#include<QObject>

class DLLPINCODESHARED_EXPORT DLLPinCode : public QObject
{
Q_OBJECT
public:
   void startPinCodeDLL(short);
   void connectPin();

private slots:
   void Slot(QString);

signals:
   void codeSignal(QString);


private:
    DLLPinCodeEngine *objectDLLPinCodeEngine;
};

#endif // DLLPINCODE_H
