#include "dllpincode.h"


void DLLPinCode::connectPin()
{
    objectDLLPinCodeEngine = new DLLPinCodeEngine;
    QObject::connect(objectDLLPinCodeEngine, SIGNAL(codeString(QString)), this, SLOT(Slot(QString)));
}

void DLLPinCode::startPinCodeDLL(short number)
{


    qDebug()<<"Rajapintafunktio";
    objectDLLPinCodeEngine->startDLLEngine(number);
    objectDLLPinCodeEngine->resize(1000,700);
    objectDLLPinCodeEngine->move(10,10);
}

void DLLPinCode::Slot(QString koodi)
{
    qDebug()<<"SLOT"+koodi;
    emit codeSignal(koodi);
}

