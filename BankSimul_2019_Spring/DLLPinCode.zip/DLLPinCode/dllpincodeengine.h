#ifndef DLLPINCODEENGINE_H
#define DLLPINCODEENGINE_H
#include<QDebug>
#include <QDialog>
#include <QtSql/QSqlDatabase>

namespace Ui {
class DLLPinCodeEngine;
}

class DLLPinCodeEngine : public QDialog
{
    Q_OBJECT

public:
    explicit DLLPinCodeEngine(QWidget *parent = 0);
    ~DLLPinCodeEngine();
public slots:
    QString startDLLEngine(short);

private slots:
    void on_pushButton_1_clicked();
    void on_pushButton_2_clicked();
    void on_pushButton_3_clicked();
    void on_pushButton_4_clicked();
    void on_pushButton_5_clicked();
    void on_pushButton_6_clicked();
    void on_pushButton_7_clicked();
    void on_pushButton_8_clicked();
    void on_pushButton_9_clicked();
    void on_pushButton_0_clicked();
    void on_pushButton_OK_clicked();
    void on_pushButton_Peruuta_clicked();
    void on_pushButton_RESET_clicked();
    void buttonFunction(QString);

signals:
    void codeString(QString);

private:
    Ui::DLLPinCodeEngine *ui;
    QString pincode;
    QString star;
    int wrongAnswer = 1;
    int rightAnswer;
    int pinCount=0;
    QString str;
    short maxCount;
};

#endif // DLLPINCODEENGINE_H
