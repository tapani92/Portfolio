#include "form.h"
#include "ui_form.h"

Form::Form(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form)
{
    ui->setupUi(this);
}

Form::~Form()
{
    delete ui;
}

void Form::on_PushButton1_clicked()
{
    pinkoodi.append("1");
    tahti.append("*");
    ui->label->setText(tahti);
}

void Form::on_pushButton2_clicked()
{
    pinkoodi.append("2");
    tahti.append("*");
    ui->label->setText(tahti);
}

void Form::on_pushButton3_clicked()
{
    pinkoodi.append("3");
    tahti.append("*");
    ui->label->setText(tahti);
}

void Form::on_pushButton4_clicked()
{
    pinkoodi.append("4");
    tahti.append("*");
    ui->label->setText(tahti);
}

void Form::on_pushButton5_clicked()
{
    pinkoodi.append("5");
    tahti.append("*");
    ui->label->setText(tahti);
}

void Form::on_pushButton6_clicked()
{
    pinkoodi.append("6");
    tahti.append("*");
    ui->label->setText(tahti);
}

void Form::on_pushButton7_clicked()
{
    pinkoodi.append("7");
    tahti.append("*");
    ui->label->setText(tahti);
}

void Form::on_pushButton8_clicked()
{
    pinkoodi.append("8");
    tahti.append("*");
    ui->label->setText(tahti);
}

void Form::on_pushButton9_clicked()
{
    pinkoodi.append("9");
    tahti.append("*");
    ui->label->setText(tahti);
}

void Form::on_pushButton0_clicked()
{
    pinkoodi.append("0");
    tahti.append("*");
    ui->label->setText(tahti);
}

void Form::on_OK_clicked()
{

}

void Form::on_Peruuta_clicked()
{

}
